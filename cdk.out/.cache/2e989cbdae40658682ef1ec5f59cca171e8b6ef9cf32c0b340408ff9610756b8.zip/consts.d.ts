export declare const CLUSTER_RESOURCE_TYPE = "Custom::AWSCDK-EKS-Cluster";
export declare const FARGATE_PROFILE_RESOURCE_TYPE = "Custom::AWSCDK-EKS-FargateProfile";
